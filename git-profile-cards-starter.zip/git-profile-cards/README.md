# Animated GitHub profile cards

This starter matches the maroon palette and Fira Code styling in your current README.

## Preview locally
1. Install Python 3.10+.
2. Install font tools: `python -m pip install fonttools brotli`.
3. Copy `data/contributions.sample.json` to `data/contributions.json`.
4. Run `STATIC=1 python generate_cards.py` for a still, screenshot-friendly final frame.
5. Run `python generate_cards.py` for animated SVGs.

The renderer downloads Fira Code, subsets it with `pyftsubset` (through fontTools), and embeds the subset as a base64 WOFF data URI. If font download/subsetting is unavailable, SVGs fall back to system monospace fonts.

## Install
Replace your existing `.github/workflows/tulkun.yml` with the bundled version, and copy `generate_cards.py`, `data/`, and the README snippet into `jahnavist04/jahnavist04`. The same daily workflow refreshes contribution data, renders and commits the cards, then runs the Git-Tulkun action.

## Before publishing
The featured project names and descriptions come from your supplied README. Since exact repository URLs were not provided, each repo card currently links to your repositories tab. Update the URL in `repo()` in `generate_cards.py` once you confirm the exact repository slugs.

Optional environment variables: `TAGLINE`, `PORTRAIT_URL`, `DISPLAY_NAME`, `GITHUB_USERNAME`, `STATIC=1`.
